#ifndef OPTIONSWINDOW_H
#define OPTIONSWINDOW_H

#include <QDialog>
#include <QDebug>
#include "uploadwindow.h"
#include "src/user.h"

namespace Ui {
class OptionsWindow;
}

class OptionsWindow : public QDialog
{
    Q_OBJECT

public:

    explicit OptionsWindow(QWidget *parent = nullptr);
    ~OptionsWindow();

private slots:
    void on_uploadBtn_clicked();

    void on_returnBtn_clicked();

    void on_photosBtn_clicked();

private:
    Ui::OptionsWindow *ui;
};

#endif // OPTIONSWINDOW_H
