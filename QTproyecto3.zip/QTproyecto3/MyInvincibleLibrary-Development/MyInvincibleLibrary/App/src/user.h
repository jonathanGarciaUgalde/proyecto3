#ifndef USER_H
#define USER_H

#include <string>
#include <QJsonObject>
#include <QVariant>
#include <QJsonDocument>

using namespace std;

class User
{
public:
    string username;
    string password;

    User();

    QJsonObject *toJsonObject();
};

#endif // USER_H
