#include "user.h"

User::User()
{

}

QJsonObject *User::toJsonObject()
{
    QJsonObject *jsonObj = new QJsonObject;

    QVariant username;
    QVariant pass;

    username = QString::fromStdString(this->username);
    pass = QString::fromStdString(this->password);

    jsonObj->insert("username", QJsonValue::fromVariant(username));
    jsonObj->insert("password", QJsonValue::fromVariant(pass));

    return jsonObj;
}
