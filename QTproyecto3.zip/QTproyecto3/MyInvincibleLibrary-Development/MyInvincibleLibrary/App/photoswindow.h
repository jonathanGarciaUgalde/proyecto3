#ifndef PHOTOSWINDOW_H
#define PHOTOSWINDOW_H
#include "client/client.h"
#include "src/user.h"
#include <vector>
#include "src/photos.h"
#include <QListWidget>

#include <QDialog>

namespace Ui {
class PhotosWindow;
}

class PhotosWindow : public QDialog
{
    Q_OBJECT

public:
    explicit PhotosWindow(QWidget *parent = nullptr);
    ~PhotosWindow();

private slots:
    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);

    void on_returnBtn_clicked();

private:
    Ui::PhotosWindow *ui;
    Client *client;
    vector<Photos*> *PhotosVector = new vector<Photos*>();
    void getPictures();
    void convertToVector(QJsonArray *a);
};

#endif // PHOTOSWINDOW_H
