#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QScreen>
#include <QDebug>
#include <QMessageBox>
#include "optionswindow.h"
#include "client/client.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    User *user;
    Client *client;

    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


    void loadWindow(string strReply);
    void showSingInMessage(string strReply);

private slots:
    void on_loginBtn_clicked();

    void on_signInBtn_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
