#include "client.h"

Client::Client()
{
    mgr = new QNetworkAccessManager;
    ip = "172.18.79.175";
}


void Client::postPhotosList(QJsonObject *obj)
{
    QNetworkRequest reqs( QUrl( QString("http://" + ip + ":9080/Proyecto3/resources/database/getPhoto") ) );
    reqs.setHeader(QNetworkRequest::ContentTypeHeader, QString("application/json"));
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    mgr->post(reqs,bytes);

    QObject::connect(mgr, &QNetworkAccessManager::finished, this, &Client::finishReplyPhotosList);

}

void Client::postPictures(QJsonObject *obj)
{
    QNetworkRequest reqs( QUrl( QString("http://" + ip + ":9080/Proyecto3/resources/database/newPhotos") ) );
    reqs.setHeader(QNetworkRequest::ContentTypeHeader, QString("application/json"));
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    mgr->post(reqs,bytes);

    QObject::connect(mgr, &QNetworkAccessManager::finished, this, &Client::finishReplyPictures);

}

void Client::postUsers(QJsonObject *obj)
{
    QNetworkRequest reqs( QUrl( QString("http://" + ip + ":9080/Proyecto3/resources/database/newUser") ) );
    reqs.setHeader(QNetworkRequest::ContentTypeHeader, QString("application/json"));
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    mgr->post(reqs,bytes);

    QObject::connect(mgr, &QNetworkAccessManager::finished, this, &Client::finishReplyUsers);

}

void Client::postCheckCredentials(QJsonObject *obj)
{
    QNetworkRequest reqs( QUrl( QString("http://" + ip + ":9080/Proyecto3/resources/database/checkCredential") ) );
    reqs.setHeader(QNetworkRequest::ContentTypeHeader, QString("application/json"));
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    mgr->post(reqs,bytes);

    QObject::connect(mgr, &QNetworkAccessManager::finished, this, &Client::finishReplyCredentials);

}

void Client::finishReplyCredentials(QNetworkReply *reply)
{
    QString strReply = (QString)reply->readAll();
    QJsonDocument jsonresponse = QJsonDocument::fromJson(strReply.toUtf8());
    QJsonArray jsonArray = jsonresponse.array();

    qInfo() << strReply;
    verifyCreds(strReply.toStdString());
}

void Client::finishReplyUsers(QNetworkReply *reply)
{
    QString strReply = (QString)reply->readAll();
    QJsonDocument jsonresponse = QJsonDocument::fromJson(strReply.toUtf8());
    QJsonArray jsonArray = jsonresponse.array();

    verifyCreds(strReply.toStdString());

    qInfo() << strReply;
}
void Client::finishReplyPictures(QNetworkReply *reply)
{
    QString strReply = (QString)reply->readAll();
    QJsonDocument jsonresponse = QJsonDocument::fromJson(strReply.toUtf8());
    QJsonArray jsonArray = jsonresponse.array();

    qInfo() << strReply;
}
void Client::finishReplyPhotosList(QNetworkReply *reply)
{
    QString strReply = (QString)reply->readAll();
    QJsonDocument jsonresponse = QJsonDocument::fromJson(strReply.toUtf8());
    QJsonArray jsonArray = jsonresponse.array();

    photosReceived(&jsonArray);



    //qInfo() << strReply;
}
