#ifndef CLIENT_H
#define CLIENT_H

#include <QtNetwork/qnetworkaccessmanager.h>
#include <QString>
#include <QJsonDocument>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QJsonArray>
#include <string>

using namespace std;

class Client: public QObject
{
    Q_OBJECT
public:
    Client();

    void postPictures(QJsonObject *obj);
    void postUsers(QJsonObject * obj);
    void postCheckCredentials(QJsonObject * obj);
    void postPhotosList(QJsonObject *obj);

private:
    QString ip;
    QNetworkAccessManager *mgr;


public slots:
    void finishReplyPictures(QNetworkReply *reply);
    void finishReplyUsers(QNetworkReply *reply);
    void finishReplyCredentials(QNetworkReply *reply);
    void finishReplyPhotosList(QNetworkReply *reply);

signals:
    void verifyCreds(string);
    void photosReceived(QJsonArray *Array);
};

#endif // CLIENT_H
