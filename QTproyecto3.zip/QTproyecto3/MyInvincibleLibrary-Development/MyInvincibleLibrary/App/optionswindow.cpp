#include "optionswindow.h"
#include "ui_optionswindow.h"
#include "photoswindow.h"

OptionsWindow::OptionsWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OptionsWindow)
{
    ui->setupUi(this);
}

OptionsWindow::~OptionsWindow()
{
    delete ui;
}

void OptionsWindow::on_uploadBtn_clicked()
{
    this->hide();

    UploadWindow *upW = new UploadWindow(this);
    upW->show();

}

void OptionsWindow::on_returnBtn_clicked()
{
    parentWidget()->show();
    this->close();
}

void OptionsWindow::on_photosBtn_clicked()
{
    this->hide();

    PhotosWindow *pW = new PhotosWindow(this);
    pW->show();
}
