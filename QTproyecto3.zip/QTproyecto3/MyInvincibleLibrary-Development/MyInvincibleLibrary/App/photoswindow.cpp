#include "photoswindow.h"
#include "ui_photoswindow.h"
#include "src/photos.h"
#include <iostream>
#include "fstream"

PhotosWindow::PhotosWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PhotosWindow)
{
    ui->setupUi(this);
    client = new Client();
    this->getPictures();
}

PhotosWindow::~PhotosWindow()
{
    delete ui;

}

void PhotosWindow::getPictures(){
    User *usuario1 = new User();

    ifstream archivo1;
    archivo1.open("source.txt",ios::in);
    string user,password;
    getline(archivo1,user);
    getline(archivo1,password);
    archivo1.close();

    usuario1->username = user;
    usuario1->password = password;


    client->postPhotosList(usuario1->toJsonObject());

     QObject::connect(client,&Client::photosReceived,this,&PhotosWindow::convertToVector);

}

void PhotosWindow::convertToVector(QJsonArray *a){
    PhotosVector->clear();

    for(auto it=a->constBegin(); it != a->constEnd(); ++it){
        const QJsonValue &val = *it;
        QJsonObject o = val.toObject();
        Photos *photo = new Photos();
        photo->write(o);
        ui->listWidget->addItem(QString::fromStdString(photo->name));
        PhotosVector->push_back(photo);
    }

}

void PhotosWindow::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    Photos *photoClicked = PhotosVector->at(ui->listWidget->currentRow());
    QByteArray base64 = QByteArray::fromStdString(photoClicked->base64);
    QImage image;
    image.loadFromData(QByteArray::fromBase64(base64),"PNG");
    ui->rodo->setPixmap(QPixmap::fromImage(image));
    ui->rodo_2->setText("Nombre: " + QString::fromStdString(photoClicked->name) + "\n"
                        "Fecha: " + QString::fromStdString(photoClicked->date) + "\n"
                        "Description: " + QString::fromStdString(photoClicked->description) + "\n");
}

void PhotosWindow::on_returnBtn_clicked()
{
    this->hide();
    parentWidget()->show();
    this->close();
}
