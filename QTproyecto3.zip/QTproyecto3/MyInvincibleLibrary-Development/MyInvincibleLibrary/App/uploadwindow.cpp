#include "uploadwindow.h"
#include "ui_uploadwindow.h"
#include "optionswindow.h"
#include "fstream"

UploadWindow::UploadWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UploadWindow)
{
    ui->setupUi(this);
    pixmap = new QPixmap();

    client = new Client;
}

UploadWindow::~UploadWindow()
{
    delete ui;
}

void UploadWindow::on_returnBtn_clicked()
{
    this->hide();
    parentWidget()->show();
    this->close();
}

void UploadWindow::on_uploadBtn_clicked()
{
    openFile();
}

void UploadWindow::openFile()
{
  QString filename =  QFileDialog::getOpenFileName(
        this,
        "Open Document",
        QDir::currentPath(),
        "All files (*.*) ;; Document files (*.doc *.rtf);; PNG files (*.png)");

  if( !filename.isNull() )
  {
      *pixmap = QPixmap(filename);
      ui->label_4->setPixmap(*pixmap);
  }

}

QString UploadWindow::convertImgToBase64()
{
    QImage tmp(ui->label_4->pixmap()->toImage());
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    tmp.save(&buffer, "PNG");
    QString Base64 = QString::fromLatin1(byteArray.toBase64().data());

    return Base64;
}

void UploadWindow::on_acceptBtn_clicked()
{

    name = ui->nameEntry->text().toStdString();
    date = ui->dateEntry->text().toStdString();
    description = ui->descriptionEntry->text().toStdString();
    string base64 = convertImgToBase64().toStdString();

    ifstream archivo;
    archivo.open("source.txt",ios::in);
    string author;
    getline(archivo,author);
    archivo.close();

    Photos *photo = new Photos();
    photo->setAtrributes(name, date, author, description, base64);

    client->postPictures(photo->toJsonObject());

}










