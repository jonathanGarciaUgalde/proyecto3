#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "fstream"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QSize size = qApp->screens()[0]->size();
    this->resize(size.width()*0.7, size.height()*0.9);

    QWidget *w = ui->widget;
    w->move(size.width()/4, size.height()/4);

    client = new Client;
    user = nullptr;

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadWindow(string strReply)
{
    if(strReply == "true"){
        this->hide();

        OptionsWindow *opW = new OptionsWindow(this);
        opW->show();
            ofstream archivo;
            archivo.open("source.txt",ios::out);
            archivo<<user->username + "\n" + user->password<<endl;
            archivo.close();
    }
    else{
        QMessageBox::StandardButton reply;
        reply = QMessageBox::information(this,
                                         "Warning", "Wrong username or password", QMessageBox::Ok);
    }

}

void MainWindow::showSingInMessage(string strReply){
    QMessageBox::StandardButton reply;

    if(strReply == "true"){
        reply = QMessageBox::information(this,
                                         "Info", "You have been signed", QMessageBox::Ok);
    }
    else{
        reply = QMessageBox::information(this,
                                         "Warning", "Username is already used", QMessageBox::Ok);
    }


}

void MainWindow::on_loginBtn_clicked()
{
    if(ui->logInNameEntry->text().isEmpty() or ui->logInPassEntry->text().isEmpty()){
        QMessageBox::StandardButton reply;
        reply = QMessageBox::information(this,
                                         "Warning", "You must fill in the blanks", QMessageBox::Ok);
    }
    else {

        user = new User;
        user->username = ui->logInNameEntry->text().toStdString();
        user->password = ui->logInPassEntry->text().toStdString();

        client->postCheckCredentials(user->toJsonObject());


        QObject::connect(client, &Client::verifyCreds, this, &MainWindow::loadWindow);

    }
}

void MainWindow::on_signInBtn_clicked()
{
    if(ui->signInNameEntry->text().isEmpty() or ui->signInPassEntry->text().isEmpty() or
            ui->signInUserEntry->text().isEmpty()){
        QMessageBox::StandardButton reply;
        reply = QMessageBox::information(this,
                                         "Warning", "You must fill in the blanks", QMessageBox::Ok);
    }
    else {
        user = new User;

        user->username = ui->signInUserEntry->text().toStdString();
        user->password = ui->signInPassEntry->text().toStdString();

        client->postUsers(user->toJsonObject());
        QObject::connect(client,&Client::verifyCreds,this,&MainWindow::showSingInMessage);

        ui->signInNameEntry->setText("");
        ui->signInUserEntry->setText("");
        ui->signInPassEntry->setText("");
    }
}
