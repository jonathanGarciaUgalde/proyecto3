#include "mainwindow.h"
#include <QApplication>
#include "fstream"
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    ofstream archivo;
    archivo.open("source.txt",ios::out);

    archivo.close();

    ifstream archivo1;
    archivo1.open("source.txt",ios::in);
    string user,password;
    getline(archivo1,user);
    getline(archivo1,password);

    archivo1.close();
    cout<<user<<endl;
    cout<<password<<endl;
    if(user == "jonathan") cout<<true<<endl;
    if(password == "1234") cout<<true<<endl;

    return a.exec();
}
