#ifndef UPLOADWINDOW_H
#define UPLOADWINDOW_H

#include <QDialog>
#include <QFileDialog>
#include <QBuffer>
#include "src/photos.h"
#include "client/client.h"


namespace Ui {
class UploadWindow;
}

class UploadWindow : public QDialog
{
    Q_OBJECT

public:
    QPixmap *pixmap;
    string name;
    string date;
    string author;
    string description;
    void openFile();
    QString convertImgToBase64();

    Client *client;

    explicit UploadWindow(QWidget *parent = nullptr);
    ~UploadWindow();

private slots:
    void on_returnBtn_clicked();

    void on_uploadBtn_clicked();

    void on_acceptBtn_clicked();

private:
    Ui::UploadWindow *ui;
};

#endif // UPLOADWINDOW_H
