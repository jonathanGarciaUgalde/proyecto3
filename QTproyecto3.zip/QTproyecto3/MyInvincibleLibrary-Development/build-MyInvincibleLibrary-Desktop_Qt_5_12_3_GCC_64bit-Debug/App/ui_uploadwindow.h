/********************************************************************************
** Form generated from reading UI file 'uploadwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPLOADWINDOW_H
#define UI_UPLOADWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UploadWindow
{
public:
    QWidget *widget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *nameEntry;
    QLineEdit *dateEntry;
    QLineEdit *descriptionEntry;
    QPushButton *uploadBtn;
    QLabel *label_4;
    QPushButton *acceptBtn;
    QPushButton *returnBtn;

    void setupUi(QDialog *UploadWindow)
    {
        if (UploadWindow->objectName().isEmpty())
            UploadWindow->setObjectName(QString::fromUtf8("UploadWindow"));
        UploadWindow->resize(720, 480);
        UploadWindow->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC"));
        widget = new QWidget(UploadWindow);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(140, 10, 431, 451));
        widget->setStyleSheet(QString::fromUtf8("background-color: #E7DECD;\n"
"border-radius: 10px;"));
        verticalLayoutWidget = new QWidget(widget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(50, 50, 151, 231));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(0, 25));
        label->setMaximumSize(QSize(16777215, 20));
        QFont font;
        font.setFamily(QString::fromUtf8("aakar"));
        font.setPointSize(18);
        label->setFont(font);
        label->setLayoutDirection(Qt::LeftToRight);
        label->setStyleSheet(QString::fromUtf8("color:black;"));
        label->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMaximumSize(QSize(16777215, 25));
        label_2->setFont(font);
        label_2->setLayoutDirection(Qt::LeftToRight);
        label_2->setStyleSheet(QString::fromUtf8("color:black;"));
        label_2->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(verticalLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 50));
        label_3->setFont(font);
        label_3->setLayoutDirection(Qt::LeftToRight);
        label_3->setStyleSheet(QString::fromUtf8("color:black;"));
        label_3->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);

        verticalLayout->addWidget(label_3);

        verticalLayoutWidget_2 = new QWidget(widget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(179, 49, 231, 231));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        nameEntry = new QLineEdit(verticalLayoutWidget_2);
        nameEntry->setObjectName(QString::fromUtf8("nameEntry"));
        nameEntry->setStyleSheet(QString::fromUtf8("background-color:#FCFCFC;\n"
"border-radius: 5px;"));

        verticalLayout_2->addWidget(nameEntry);

        dateEntry = new QLineEdit(verticalLayoutWidget_2);
        dateEntry->setObjectName(QString::fromUtf8("dateEntry"));
        dateEntry->setStyleSheet(QString::fromUtf8("background-color:#FCFCFC;\n"
"border-radius: 5px;"));

        verticalLayout_2->addWidget(dateEntry);

        descriptionEntry = new QLineEdit(verticalLayoutWidget_2);
        descriptionEntry->setObjectName(QString::fromUtf8("descriptionEntry"));
        descriptionEntry->setMinimumSize(QSize(0, 50));
        descriptionEntry->setStyleSheet(QString::fromUtf8("background-color:#FCFCFC;\n"
"border-radius: 5px;"));

        verticalLayout_2->addWidget(descriptionEntry);

        uploadBtn = new QPushButton(widget);
        uploadBtn->setObjectName(QString::fromUtf8("uploadBtn"));
        uploadBtn->setGeometry(QRect(30, 400, 101, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("aakar"));
        font1.setPointSize(15);
        uploadBtn->setFont(font1);
        uploadBtn->setStyleSheet(QString::fromUtf8("#uploadBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#uploadBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));
        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 290, 101, 101));
        label_4->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC"));
        label_4->setScaledContents(true);
        acceptBtn = new QPushButton(widget);
        acceptBtn->setObjectName(QString::fromUtf8("acceptBtn"));
        acceptBtn->setGeometry(QRect(220, 340, 121, 51));
        acceptBtn->setFont(font1);
        acceptBtn->setStyleSheet(QString::fromUtf8("#acceptBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#acceptBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));
        returnBtn = new QPushButton(UploadWindow);
        returnBtn->setObjectName(QString::fromUtf8("returnBtn"));
        returnBtn->setGeometry(QRect(600, 430, 89, 25));
        returnBtn->setStyleSheet(QString::fromUtf8("#returnBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#returnBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));

        retranslateUi(UploadWindow);

        QMetaObject::connectSlotsByName(UploadWindow);
    } // setupUi

    void retranslateUi(QDialog *UploadWindow)
    {
        UploadWindow->setWindowTitle(QApplication::translate("UploadWindow", "Dialog", nullptr));
        label->setText(QApplication::translate("UploadWindow", "Nombre:", nullptr));
        label_2->setText(QApplication::translate("UploadWindow", "fecha:", nullptr));
        label_3->setText(QApplication::translate("UploadWindow", "Description:", nullptr));
        uploadBtn->setText(QApplication::translate("UploadWindow", "Find", nullptr));
        label_4->setText(QString());
        acceptBtn->setText(QApplication::translate("UploadWindow", "Accept", nullptr));
        returnBtn->setText(QApplication::translate("UploadWindow", "Return", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UploadWindow: public Ui_UploadWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPLOADWINDOW_H
