/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *widget;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_7;
    QLineEdit *logInNameEntry;
    QLabel *label_8;
    QLineEdit *logInPassEntry;
    QFrame *line_2;
    QPushButton *loginBtn;
    QLabel *label_9;
    QLabel *label_10;
    QLineEdit *signInNameEntry;
    QLabel *label_11;
    QLineEdit *signInUserEntry;
    QLabel *label_12;
    QLineEdit *signInPassEntry;
    QPushButton *signInBtn;
    QLabel *label;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1024, 768);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(310, 130, 361, 501));
        widget->setStyleSheet(QString::fromUtf8("background-color: #E7DECD;\n"
"border-radius: 10px;"));
        verticalLayoutWidget_2 = new QWidget(widget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(0, 0, 361, 502));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout_2->setContentsMargins(10, 10, 10, 10);
        label_7 = new QLabel(verticalLayoutWidget_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        QFont font;
        font.setFamily(QString::fromUtf8("aakar"));
        font.setPointSize(15);
        label_7->setFont(font);
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_7);

        logInNameEntry = new QLineEdit(verticalLayoutWidget_2);
        logInNameEntry->setObjectName(QString::fromUtf8("logInNameEntry"));
        logInNameEntry->setFont(font);
        logInNameEntry->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC"));
        logInNameEntry->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(logInNameEntry);

        label_8 = new QLabel(verticalLayoutWidget_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font);
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        label_8->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_8);

        logInPassEntry = new QLineEdit(verticalLayoutWidget_2);
        logInPassEntry->setObjectName(QString::fromUtf8("logInPassEntry"));
        logInPassEntry->setFont(font);
        logInPassEntry->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC;"));
        logInPassEntry->setEchoMode(QLineEdit::Password);
        logInPassEntry->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(logInPassEntry);

        line_2 = new QFrame(verticalLayoutWidget_2);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_2);

        loginBtn = new QPushButton(verticalLayoutWidget_2);
        loginBtn->setObjectName(QString::fromUtf8("loginBtn"));
        loginBtn->setMinimumSize(QSize(0, 80));
        QFont font1;
        font1.setFamily(QString::fromUtf8("aakar"));
        font1.setPointSize(18);
        font1.setBold(false);
        font1.setWeight(50);
        loginBtn->setFont(font1);
        loginBtn->setCursor(QCursor(Qt::PointingHandCursor));
        loginBtn->setFocusPolicy(Qt::ClickFocus);
        loginBtn->setStyleSheet(QString::fromUtf8("#loginBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#loginBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));

        verticalLayout_2->addWidget(loginBtn);

        label_9 = new QLabel(verticalLayoutWidget_2);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("aakar"));
        font2.setPointSize(13);
        label_9->setFont(font2);
        label_9->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        label_9->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_9);

        label_10 = new QLabel(verticalLayoutWidget_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setFont(font);
        label_10->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        label_10->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_10);

        signInNameEntry = new QLineEdit(verticalLayoutWidget_2);
        signInNameEntry->setObjectName(QString::fromUtf8("signInNameEntry"));
        signInNameEntry->setFont(font);
        signInNameEntry->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC;"));
        signInNameEntry->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(signInNameEntry);

        label_11 = new QLabel(verticalLayoutWidget_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setFont(font);
        label_11->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        label_11->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_11);

        signInUserEntry = new QLineEdit(verticalLayoutWidget_2);
        signInUserEntry->setObjectName(QString::fromUtf8("signInUserEntry"));
        signInUserEntry->setFont(font);
        signInUserEntry->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC;"));
        signInUserEntry->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(signInUserEntry);

        label_12 = new QLabel(verticalLayoutWidget_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setFont(font);
        label_12->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        label_12->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_12);

        signInPassEntry = new QLineEdit(verticalLayoutWidget_2);
        signInPassEntry->setObjectName(QString::fromUtf8("signInPassEntry"));
        signInPassEntry->setFont(font);
        signInPassEntry->setStyleSheet(QString::fromUtf8("background-color: #FCFCFC;"));
        signInPassEntry->setEchoMode(QLineEdit::Password);
        signInPassEntry->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(signInPassEntry);

        signInBtn = new QPushButton(verticalLayoutWidget_2);
        signInBtn->setObjectName(QString::fromUtf8("signInBtn"));
        signInBtn->setMinimumSize(QSize(0, 50));
        signInBtn->setFont(font);
        signInBtn->setCursor(QCursor(Qt::PointingHandCursor));
        signInBtn->setStyleSheet(QString::fromUtf8("#signInBtn{\n"
"background-color: #0A122A;\n"
"color: white;\n"
"}\n"
"#signInBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));

        verticalLayout_2->addWidget(signInBtn);

        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(380, 90, 591, 61));
        QFont font3;
        font3.setFamily(QString::fromUtf8("aakar"));
        font3.setPointSize(40);
        font3.setBold(true);
        font3.setWeight(75);
        label->setFont(font3);
        label->setStyleSheet(QString::fromUtf8("color: #0A122A;"));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "USERNAME", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "PASSWORD", nullptr));
        logInPassEntry->setInputMask(QString());
        loginBtn->setText(QApplication::translate("MainWindow", "Log in", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "or", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "NAME:", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "USERNAME", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "PASSWORD", nullptr));
        signInBtn->setText(QApplication::translate("MainWindow", "Sign in", nullptr));
        label->setText(QApplication::translate("MainWindow", "WELCOME TO MYIDE!", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
