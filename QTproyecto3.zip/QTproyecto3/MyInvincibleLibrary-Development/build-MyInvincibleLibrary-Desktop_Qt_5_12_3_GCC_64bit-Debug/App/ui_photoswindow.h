/********************************************************************************
** Form generated from reading UI file 'photoswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PHOTOSWINDOW_H
#define UI_PHOTOSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_PhotosWindow
{
public:
    QLabel *rodo;
    QListWidget *listWidget;
    QLabel *rodo_2;
    QPushButton *returnBtn;

    void setupUi(QDialog *PhotosWindow)
    {
        if (PhotosWindow->objectName().isEmpty())
            PhotosWindow->setObjectName(QString::fromUtf8("PhotosWindow"));
        PhotosWindow->resize(796, 507);
        rodo = new QLabel(PhotosWindow);
        rodo->setObjectName(QString::fromUtf8("rodo"));
        rodo->setGeometry(QRect(378, 30, 491, 291));
        rodo->setScaledContents(true);
        listWidget = new QListWidget(PhotosWindow);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(22, 32, 349, 221));
        listWidget->setStyleSheet(QString::fromUtf8("font: 57 20pt \"Ubuntu\";"));
        rodo_2 = new QLabel(PhotosWindow);
        rodo_2->setObjectName(QString::fromUtf8("rodo_2"));
        rodo_2->setGeometry(QRect(378, 352, 279, 127));
        rodo_2->setStyleSheet(QString::fromUtf8("font: 18pt \"Ubuntu\";"));
        rodo_2->setScaledContents(true);
        returnBtn = new QPushButton(PhotosWindow);
        returnBtn->setObjectName(QString::fromUtf8("returnBtn"));
        returnBtn->setGeometry(QRect(694, 476, 89, 25));
        returnBtn->setStyleSheet(QString::fromUtf8("#returnBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#returnBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));

        retranslateUi(PhotosWindow);

        QMetaObject::connectSlotsByName(PhotosWindow);
    } // setupUi

    void retranslateUi(QDialog *PhotosWindow)
    {
        PhotosWindow->setWindowTitle(QApplication::translate("PhotosWindow", "Dialog", nullptr));
        rodo->setText(QString());
        rodo_2->setText(QString());
        returnBtn->setText(QApplication::translate("PhotosWindow", "Return", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PhotosWindow: public Ui_PhotosWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PHOTOSWINDOW_H
