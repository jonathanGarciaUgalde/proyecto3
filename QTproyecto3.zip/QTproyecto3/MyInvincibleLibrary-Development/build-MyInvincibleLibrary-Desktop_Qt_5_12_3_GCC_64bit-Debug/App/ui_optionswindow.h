/********************************************************************************
** Form generated from reading UI file 'optionswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPTIONSWINDOW_H
#define UI_OPTIONSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_OptionsWindow
{
public:
    QWidget *widget;
    QPushButton *photosBtn;
    QPushButton *uploadBtn;
    QLabel *label;
    QLabel *label_2;
    QPushButton *returnBtn;

    void setupUi(QDialog *OptionsWindow)
    {
        if (OptionsWindow->objectName().isEmpty())
            OptionsWindow->setObjectName(QString::fromUtf8("OptionsWindow"));
        OptionsWindow->resize(720, 480);
        OptionsWindow->setStyleSheet(QString::fromUtf8("#OptionsWindow{\n"
"background-color: #FCFCFC;\n"
"}"));
        widget = new QWidget(OptionsWindow);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(220, 90, 281, 301));
        widget->setStyleSheet(QString::fromUtf8("background-color: #E7DECD;\n"
"border-radius: 10px;"));
        photosBtn = new QPushButton(widget);
        photosBtn->setObjectName(QString::fromUtf8("photosBtn"));
        photosBtn->setGeometry(QRect(30, 50, 220, 70));
        photosBtn->setStyleSheet(QString::fromUtf8("#photosBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#photosBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));
        uploadBtn = new QPushButton(widget);
        uploadBtn->setObjectName(QString::fromUtf8("uploadBtn"));
        uploadBtn->setGeometry(QRect(30, 170, 220, 70));
        uploadBtn->setStyleSheet(QString::fromUtf8("#uploadBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#uploadBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 70, 40, 35));
        label->setStyleSheet(QString::fromUtf8("border-image: url(:/images/photosImg.png);"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 190, 40, 35));
        label_2->setStyleSheet(QString::fromUtf8("border-image: url(:/images/uploadImg.png);"));
        returnBtn = new QPushButton(OptionsWindow);
        returnBtn->setObjectName(QString::fromUtf8("returnBtn"));
        returnBtn->setGeometry(QRect(580, 400, 91, 41));
        returnBtn->setStyleSheet(QString::fromUtf8("#returnBtn{\n"
"background-color: #0A122A;\n"
"color:white\n"
"}\n"
"#returnBtn:hover{\n"
"background-color: #20273D\n"
"}\n"
""));

        retranslateUi(OptionsWindow);

        QMetaObject::connectSlotsByName(OptionsWindow);
    } // setupUi

    void retranslateUi(QDialog *OptionsWindow)
    {
        OptionsWindow->setWindowTitle(QApplication::translate("OptionsWindow", "Dialog", nullptr));
        photosBtn->setText(QApplication::translate("OptionsWindow", "Photos", nullptr));
        uploadBtn->setText(QApplication::translate("OptionsWindow", "Upload", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        returnBtn->setText(QApplication::translate("OptionsWindow", "Return", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OptionsWindow: public Ui_OptionsWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPTIONSWINDOW_H
